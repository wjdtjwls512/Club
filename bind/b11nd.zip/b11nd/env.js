const SERVER_URL = `https://oral-container-boots-uploaded.trycloudflare.com/`
export default SERVER_URL